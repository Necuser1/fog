import logging
class Handler:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        logger_handler = logging.FileHandler('python_logging.log')
        logger_handler.name='main'
        logger_formatter = logging.Formatter('%(asctime)s -- %(levelname)s -- %(message)s')
        logger_handler.setFormatter(logger_formatter)
        self.logger.addHandler(logger_handler)
        self.logger.info('Completed configuring logger()!')
    def get_worninglevel(self):
        self.logger.setLevel(logging.WARNING)
        return self.logger
    def get_debuglevel(self):
        self.logger.setLevel(logging.DEBUG)
        return self.logger
    def get_errorlevel(self):
        self.logger.setLevel(logging.ERROR)
        return self.logger
    def get_criticallevel(self):
        self.logger.setLevel(logging.CRITICAL)
        return self.logger
