from LogerHandler import Handler
obj=Handler()
logger=obj.get_debuglevel()
current_number = 0
logger.debug(current_number)
logger.info('Still clearing number!!')


