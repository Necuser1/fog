export PYTHONPATH="$PYTHONPATH:/root/TRANSFORMER/Next_transform/fogflow/ngsildAdapter/module"

